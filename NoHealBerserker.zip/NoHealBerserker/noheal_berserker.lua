local function berserker_active()
	local pm = managers.player
	return pm and (pm:has_category_upgrade("player", "melee_damage_health_ratio_multiplier")
		or pm:has_category_upgrade("player", "damage_health_ratio_multiplier"))
end

local reviving = setmetatable({}, { __mode = "k" })
local original_revive = PlayerDamage.revive

function PlayerDamage:revive(...)
	local previous = reviving[self]
	reviving[self] = true
	local ok, result = pcall(original_revive, self, ...)
	reviving[self] = previous
	if not ok then
		error(result, 0)
	end
	return result
end

local orig_set_health = PlayerDamage.set_health
function PlayerDamage:set_health(health)
	if not reviving[self] and berserker_active() then
		local current = self:get_real_health()
		-- Only block while alive so revives (from 0 health) still work
		if current and current > 0 and health > current then
			return
		end
	end
	return orig_set_health(self, health)
end

local orig_restore_health = PlayerDamage.restore_health
function PlayerDamage:restore_health(...)
	if not reviving[self] and berserker_active() and self:get_real_health() > 0 then
		return
	end
	return orig_restore_health(self, ...)
end

if PlayerDamage.band_aid_health then
	local orig_band_aid = PlayerDamage.band_aid_health
	function PlayerDamage:band_aid_health(...)
		if not reviving[self] and berserker_active() then
			return
		end
		return orig_band_aid(self, ...)
	end
end
